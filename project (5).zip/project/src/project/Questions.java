/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

/**
 *
 * @author duncan
 */
public class Questions {
    private static int length =5;
    private static int width =5;
    private static String[][] questionholder = new String[length][width];
    public static String[][] allbuttons;
    private List<Button> holder = new ArrayList<>(); 
    public static List<String[]> Bank = new ArrayList<>();
    public static List<String[]> container = new ArrayList<>();
    private static Random R = new Random();
  /*  private static String[] aircraft= {"aircraft","plane", "car", "boat", "motorcycle"};
    private static String[] randoms= {"randoms","Yes", "No", "Maybe so", "Encyclopedia", "no" + '\n' + "yes"}; 
    private static String[] sitting= {"sitting","chair", "desk", "seat", "bed", "lap"};
    private static String[] directions= {"directions","North", "South", "East", "West"};
    private static String[] continets= {"continets","North America", "South America", "Africa", "Europe", "Asia", "Australia"};
    private static String[] planets= {"planets","uranus", "Mercury", "mars", "earth", "venus", "neptune", "Jupiter"};
 */ private static String[] Porifera= {"Porifera","Examples:" + '\n' + "sponge", "Symmetry:" + '\n' + "none/radial", "Lifestyle:" + '\n' + "free, fresh/marine", "Rep sex(sexual):" + '\n'+ "hermaphrodite", "Asexual:" + '\n' + "budding"
    ,"Skeletal:" + '\n' + "spicules", "Digestive:" + '\n' + "none", "Circulatory:" + '\n' + "none", "Respiratory:" + '\n' + "surface exchange", "Nervous:" + '\n' + "none"};
    private static String[] Cnidaria= {"Cnidaria","Examples:" + '\n' + "sea jelly, coral", "Symmetry:" + '\n' + "radial", "Lifestyle:" + '\n' + "free, fresh/marine", "Rep sex(sexual):" + '\n'+ "hermaphrodite", "Asexual:" + '\n' + "budding"
    ,"Skeletal:" + '\n' + "none", "Digestive:" + '\n' + "single opening", "Circulatory:" + '\n' + "gastrovascular cavity", "Respiratory:" + '\n' + "surface exchange", "Nervous:" + '\n' + "nerve net"};    
    private static String[] Platyhelminthes= {"Platyhelminthes","Examples:" + '\n' + "tape worm, fluke, planaria", "Symmetry:" + '\n' + "bilateral", "Lifestyle:" + '\n' + "free, fresh/marine, parasitic, land", "Rep sex(sexual):" + '\n'+ "hermaphrodite", "Asexual:" + '\n' + "fragmentation"
    ,"Skeletal:" + '\n' + "none", "Digestive:" + '\n' + "single opening", "Circulatory:" + '\n' + "gastrovascular cavity", "Respiratory:" + '\n' + "surface exchange", "Nervous:" + '\n' + "nerve net, ventral cord"};     
    private static String[] Nematoda= {"Nematoda","Examples:" + '\n' + "Acaris, soil nematode", "Symmetry:" + '\n' + "bilateral", "Lifestyle:" + '\n' + "free, fresh/marine, parasitic, land", "Rep sex(Sexual):" + '\n'+ "separate", "Asexual:" + '\n' + "none"
    ,"Skeletal:" + '\n' + "none", "Digestive:" + '\n' + "mouth and anus(alimentary canal)", "Circulatory:" + '\n' + "none", "Respiratory:" + '\n' + "surface exchange", "Nervous:" + '\n' + "nerve net, ventral cord"};     
    private static String[] Annelida= {"Annelida","Examples:" + '\n' + "earthworm, leech", "Symmetry:" + '\n' + "bilateral", "Lifestyle:" + '\n' + "free, fresh/marine, parasitic, land", "Rep sex(Sexual):" + '\n'+ "hermaphrodite", "Asexual:" + '\n' + "none"
    ,"Skeletal:" + '\n' + "hydrostatic", "Digestive:" + '\n' + "mouth and anus(alimentary canal)", "Circulatory:" + '\n' + "closed", "Respiratory:" + '\n' + "surface exchange", "Nervous:" + '\n' + "brain, ventral cord"};     
    private static String[] Mollusca= {"Mollusca","Examples:" + '\n' + "sea star, sea cucumber, sea urchin", "Symmetry:" + '\n' + "bilateral", "Lifestyle:" + '\n' + "free, fresh/marine, land", "Rep sex(Sexual):" + '\n'+ "hermaphrodite and separate", "Asexual:" + '\n' + "none"
    ,"Skeletal:" + '\n' + "shell", "Digestive:" + '\n' + "mouth and anus(alimentary canal)", "Circulatory:" + '\n' + "open", "Respiratory:" + '\n' + "gills", "Nervous:" + '\n' + "brain, ventral cord"};     
    private static String[] Echinodermata= {"Echinodermata","Examples:" + '\n' + "sea star, sea cucumber, sea urchin", "Symmetry:" + '\n' + "radial (as adult)", "Lifestyle:" + '\n' + "free, marine", "Rep sex(Sexual):" + '\n'+ "separate", "Asexual:" + '\n' + "fragmentation"
    ,"Skeletal:" + '\n' + "endoskeleton", "Digestive:" + '\n' + "mouth and anus(alimentary canal)", "Circulatory:" + '\n' + "closed", "Respiratory:" + '\n' + "water-vascular, system & gills", "Nervous:" + '\n' + "nerve ring, radial nerves"};     
    private static String[] Arthropoda= {"Arthropoda","Examples:" + '\n' + "insect centipede, spider millipede, crab shrimp lobster", "Symmetry:" + '\n' + "bilateral", "Lifestyle:" + '\n' + "free, fresh/marine, parasitic, land", "Rep sex(Sexual):" + '\n'+ "separate", "Asexual:" + '\n' + "none"
    ,"Skeletal:" + '\n' + "exoskeleton", "Digestive:" + '\n' + "mouth and anus(alimentary canal)", "Circulatory:" + '\n' + "open", "Respiratory:" + '\n' + "tracheae, gills, book lungs", "Nervous:" + '\n' + "brain, ventral cord"};     
                 
    
    private static String[] blank;

    private static void addcontainer(){
    /*    container.add(aircraft); container.add(randoms); container.add(sitting); container.add(planets); container.add(continets); container.add(directions); */
    container.add(Porifera); container.add(Cnidaria); container.add(Platyhelminthes); container.add(Nematoda); container.add(Annelida); container.add(Mollusca); container.add(Echinodermata); container.add(Arthropoda);
    }

    public static String[] getgroup(ChoiceBox choices, List<AnswerContainer> AC){
        container.clear();
        addcontainer();
        for(int i=0; i<container.size(); ++i){
            if(choices.getValue() ==container.get(i)[0]){
                blank = container.get(i);
                Bank.add(container.get(i));
                container.remove(i);
                return blank;
                
            }
        }
        return blank;
    }
    
    
    public void reset(List<AnswerContainer> AC, List<Button> holder, GridPane answers){ 
        for(int i=0; i<AC.size(); ++i){
            AC.get(i).getButtonList().clear();
        }
        
        for(int i=0; i<holder.size(); ++i){
            for(int ii=1; ii<AC.size()+1; ++ii){
                if(("pane"+ii).equals(holder.get(i).getId())){
                    holder.get(i).setUnderline(false);
                    int fale =1;
                        for(int row =0; row<questionholder.length; ++row){
                            for(int col =0; col<questionholder[row].length; ++col){
                                if(holder.get(i).getText().equals(questionholder[col][row])){
                                    answers.add(holder.get(i), row, col);
                                    fale=0;
                                    break;
                    }
                }           if(fale==0){
                                break;                
        } 
            } 
                    holder.get(i).setId(i + ii+ "");
                }
            }

        }
        for(int i=0; i<AC.size(); ++i){
            AC.get(i).setNeeds(0);
            AC.get(i).setHas(0);
            AC.get(i).setAnswershas(0);
        }
    }
    
    public static String[] getrandom(){
    if(container.size() < 1){
        addcontainer();}
        int random = R.nextInt(container.size());
        System.out.println(random);
        String[] holder = container.get(random);
        Bank.add(container.get(random));
        System.out.println(Bank.size());
        container.remove(random);
        return holder;
    }
    
    public static void buttoncheck(Button b, List<AnswerContainer> AC, GridPane answers){
        if (b.isUnderline()){
            int index =0;
            while(!b.getId().equals(AC.get(index).getGridid())){
                ++index;
            }
            String holder = b.getId();
            b.setId("oh");
            AC.get(index).getButtonList().remove(b);
            b.setId(holder);
            b.setUnderline(false);
            int fale =1;
            for(int row =0; row<questionholder.length; ++row){
                for(int col =0; col<questionholder[row].length; ++col){
                    if(b.getText().equals(questionholder[col][row])){
                        if(row==0 && col ==0){
                            answers.add(b, row+1, col+1);
                            fale=0;
                            break;
                        }
                        answers.add(b, row, col);
                        fale=0;
                        break;
                    }
                }                if(fale==0){
                    break;                
        } 
            }
 
            AC.get(index).setHas(AC.get(index).getHas() - 1);   
        }
    }
    
    
    public void addQuestions(List<Button> ids, List<AnswerContainer> AC, int amount){
        
        for(int i=0; i<ids.size(); ++i){
        holder.add(ids.get(i));
        }
        List<Integer> numbers = new ArrayList<>();
        for(int row =0; row<questionholder.length; ++row){
            for(int col =0; col<questionholder[row].length; ++col){
                questionholder[row][col] = " ";
                
            }
        } 
        System.out.println(ids.size());        
        while(amount>0){
            Button button = new Button();
            int random = R.nextInt(ids.size());
            int counter =0;
            while(counter<ids.size()){
                if((random + "B").equals(ids.get(counter).getId())){
                    random = R.nextInt(ids.size());
                    counter =0;
                }
                ++counter;
            }
            String[] B = Bank.get(R.nextInt(Bank.size()));
            
            for(int i=0; i<AC.size(); ++i){
                if(Arrays.equals(B, AC.get(i).getAnswer())){
                    int needs = AC.get(i).getNeeds() + 1;
                    AC.get(i).setNeeds(needs);
            } 
            }
            Bank.get(R.nextInt(Bank.size()));
            String random2 = B[R.nextInt(B.length-1) +1];
            
              ids.get(random).setText(random2);
              ids.get(random).setVisible(true);
              int pick =0;
            int breaker =0;
            for (int row =0; row<questionholder.length; ++row){
               for( int col =0; col< questionholder[row].length; ++col ){
                   
                   if(pick == random){
                       questionholder[row][col] = random2;        
                       breaker =1;
                       break;
                   }++pick;
                   
               }
               if(breaker ==1){
                   break;
               }
            }
              
 
              ids.remove(random);
              ids.add(random,button);
              System.out.println(random);
              button.setId(random +"B");
              --amount;

    }
}
}
