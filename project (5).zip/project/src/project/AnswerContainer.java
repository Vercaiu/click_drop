/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.List;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import static javax.swing.text.StyleConstants.Bold;
import static javax.swing.text.StyleConstants.Italic;

/**
 *
 * @author duncan
 */
public class AnswerContainer {
    private Button emptybutton;
    private  int has;
    private  int needs;
    private int answershas;
    private String gridId;
    private String[] answer;
    private List<Button> buttonlist;
    AnswerContainer(int _needs, int _has, int _answershas, String _gridId, String[] _answers, List<Button> _buttonlist){
        gridId = _gridId;
        needs = _needs;
        has   = _has;
        answer = _answers;
        buttonlist = _buttonlist;
        answershas = _answershas;
        
}

    public int getAnswershas() {
        return answershas;
    }

    public void setAnswershas(int answershas) {
        this.answershas = answershas;
    }

    public void setNeeds(int needs) {
        this.needs = needs;
    }

    public String[] getAnswer() {
        return answer;
    }

    public List<Button> getButtonList() {
        return buttonlist;
    }

    public void setButtonList(List<Button> button) {
        this.buttonlist = button;
    }

    public String getGridid() {
        return gridId;
    }
    
    public int getHas() {
        return has;
    }

    public int getNeeds() {
        return needs;
    }

    public void setHas(int has) {
        this.has = has;
    }
}
