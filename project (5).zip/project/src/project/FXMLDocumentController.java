/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.DragEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import static javax.swing.text.StyleConstants.Bold;

/**
 *
 * @author duncan
 */
public class FXMLDocumentController implements Initializable {
    @FXML private Button back;
    @FXML private  GridPane pane1;
    @FXML private  GridPane pane2;
    @FXML private  GridPane pane3;
    @FXML private  GridPane pane4;
    @FXML private  GridPane pane5;
    @FXML private Button id1; 
    @FXML private Button id2; 
    @FXML private Button id3; 
    @FXML private Button id4; 
    @FXML private Button id5;
    @FXML private Button id6; 
    @FXML private Button id7; 
    @FXML private Button id8; 
    @FXML private Button id9; 
    @FXML private Button id10;
    @FXML private Button id11; 
    @FXML private Button id12; 
    @FXML private Button id13; 
    @FXML private Button id14; 
    @FXML private Button id15;
    @FXML private Button id16; 
    @FXML private Button id17; 
    @FXML private Button id18; 
    @FXML private Button id19; 
    @FXML private Button id20;
    @FXML private Button id21; 
    @FXML private Button id22; 
    @FXML private Button id23; 
    @FXML private Button id24; 
    @FXML private Button id25;
    @FXML private  Label label1; 
    @FXML private  Label label2;
    @FXML private  Label label3;
    @FXML private  Label label4;
    @FXML private  Label label5;
    @FXML private GridPane answers;
    @FXML public Label labelinfo;
    @FXML private Label labelcorrect1;
    @FXML private Label labelcorrect2;
    @FXML private Label labelcorrect3;
    @FXML private Label labelcorrect4;
    @FXML private Label labelcorrect5;
    
    private int level =1;
    private List<Button> ids = new ArrayList<>();    
    private List<Button> holder = new ArrayList<>();
    private int numbers = 10;
    public GridPane[] panes = new GridPane[5];
    private Random R = new Random();
    private Button activebutton;
    
        @FXML
    void switcharound(ActionEvent event) {
    reset(numbers);
    Label[] Correctlabel = {labelcorrect1, labelcorrect2, labelcorrect3, labelcorrect4, labelcorrect5};
    AnswerContainerManager.checkhas(HomescreenController.answerslist, Correctlabel);
    }
    
    @FXML
    void addanswer(MouseEvent event) {
     GridPane grid =   (GridPane) event.getSource(); 
    Questions.buttoncheck(activebutton, HomescreenController.answerslist, answers); 
     AnswerContainerManager.addquestion(grid, activebutton, HomescreenController.answerslist, holder);
     AnswerContainerManager ACM = new AnswerContainerManager();
   
     if(AnswerContainerManager.checkwinning(HomescreenController.answerslist)){
         if(level >= 3){
             labelinfo.setText("You Win");
             for(int i=0; i<holder.size(); ++i){
                 
             }
         } else{
            labelinfo.setText("Level: " + (++level));
            reset(numbers+=2); }
     }
     Label[] Correctlabel = {labelcorrect1, labelcorrect2, labelcorrect3, labelcorrect4, labelcorrect5};
     AnswerContainerManager.checkhas(HomescreenController.answerslist, Correctlabel);

    }
    
    @FXML
    void answerclick(ActionEvent Event){
        System.out.println("yikessssss");
        Button button = (Button) Event.getSource();
        System.out.println(button.getId());
        activebutton= button;   
        Questions.buttoncheck(activebutton, HomescreenController.answerslist, answers); 
        AnswerContainerManager testing = new AnswerContainerManager();
        testing.containerfixer(HomescreenController.answerslist, activebutton, panes, answers);
    }
        @FXML
    void gotohomepage(ActionEvent event) throws Exception {
        reset(numbers);
        HomescreenController.answerslist.clear();
        ids.clear();
        holder.clear();
        Utility.changetoscene("homescreen.fxml", event, getClass());
    }

    private void reset(int amount){
        Questions test = new Questions();
        if(ids.size()>1){
        test.reset(HomescreenController.answerslist, holder, answers);            
        }

                ids.clear();
        ids.add(id1); ids.add(id2); ids.add(id3); ids.add(id4); ids.add(id5);
        ids.add(id6); ids.add(id7); ids.add(id8); ids.add(id9); ids.add(id10);
        ids.add(id11); ids.add(id12); ids.add(id13); ids.add(id14); ids.add(id15);
        ids.add(id16); ids.add(id17); ids.add(id18); ids.add(id19); ids.add(id20);
        ids.add(id21); ids.add(id22); ids.add(id23); ids.add(id24); ids.add(id25);
        for(int i=0; i<ids.size(); ++i){
            ids.get(i).setId("id"+ (i +1));
        }
        holder.removeAll(holder);
        for(int i=0; i<ids.size(); ++i){
        holder.add(ids.get(i));}
        for(int i =0; i<ids.size(); ++i){
            ids.get(i).setVisible(false);
        }  
        test.addQuestions(ids, HomescreenController.answerslist, amount);
        AnswerContainerManager test2 = new AnswerContainerManager();
        Label[] labels = {label1, label2, label3, label4, label5};
        test2.resetname(labels, HomescreenController.answerslist);

        
     }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ids.clear();
        reset(numbers);
        activebutton= id20;
        panes[0]= pane1; panes[1]= pane2; panes[2]= pane3; panes[3]= pane4; panes[4]= pane5; 
    }    
    
}
