/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.IOException;
import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author duncan
 */
public class Utility {
    
    // Utility.changetoscene("my.fxml", event, getClass());
    public static void changetoscene(String sceneFinder, Event iEvent, Class aClass
    ) throws Exception{
            Parent root = FXMLLoader.load(aClass.getResource(sceneFinder));
        Scene scene = new Scene(root);
        Stage stage= (Stage)((Node) iEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
        stage.show();
    }
}
