/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author duncan
 */
public class HomescreenController implements Initializable {
    @FXML
    private Button page;
    @FXML
    private ChoiceBox<String> choicebox1;

    @FXML
    private ChoiceBox<String> choicebox2;

    @FXML
    private ChoiceBox<String> choicebox3;

    @FXML
    private ChoiceBox<String> choicebox5;

    @FXML
    private ChoiceBox<String> choicebox4;
    @FXML
    private Label warning;

    @FXML
    private CheckBox fakeanswers;
    private String[] array ={"Random", "none", /*"continets", "planets", "aircraft", "sitting", "randoms",
        "directions", */ "Porifera", "Cnidaria", "Platyhelminthes", "Nematoda", "Annelida", "Mollusca", "Echinodermata", "Arthropoda"};
    public ChoiceBox<String> chooseround;
    private List<Button> pane1 = new ArrayList<>();
    private List<Button> pane2 = new ArrayList<>();
    private List<Button> pane3 = new ArrayList<>();
    private List<Button> pane4 = new ArrayList<>();
    private List<Button> pane5 = new ArrayList<>();
    @FXML
    void addfakeanswers(ActionEvent event) {

    }
    public static List<AnswerContainer> answerslist = new ArrayList<>();
    @FXML
    private void gotopage(ActionEvent event) throws Exception {
        ChoiceBox[] choiceboxarray ={choicebox1, choicebox2, choicebox3, choicebox4, choicebox5};
        List<List<Button>> panes = new ArrayList<>();
        Questions.Bank.clear();
        answerslist.clear();
        panes.add(pane1); panes.add(pane2); panes.add(pane3); panes.add(pane4); panes.add(pane5);
        int decide =0;
        for(int i=0; i<choiceboxarray.length; ++i){
            for(int ii=0; ii<choiceboxarray.length; ++ii){
                
                if(choiceboxarray[i].getValue() == choiceboxarray[ii].getValue() && choiceboxarray[i].getValue() != "none" &&
                        choiceboxarray[i].getValue() != "Random" && choiceboxarray[i] != choiceboxarray[ii] ){
                   
                    
                    decide=1;
                    break; 
                }
            }
            if(decide ==1){
                break;
            }
            
        }
        if(decide ==0){
        List<AnswerContainer> lists = new ArrayList<>();
        int counter =1;
        for(int i=0; i<5; ++i){
            if(choiceboxarray[i].getValue() != "none" && choiceboxarray[i].getValue() != "Random"){
                AnswerContainer ac1 = new AnswerContainer(0, 0 ,0,"pane" +counter, Questions.getgroup(choiceboxarray[i], answerslist), panes.get(counter -1));
                lists.add(ac1);
                ++counter;
        }   else if(choiceboxarray[i].getValue().equals("Random")){
            ++counter;
        }            
        }
        counter =1;
Random R = new Random();        
        for(int i=0; i<5; ++i){
            if(choiceboxarray[i].getValue() != "none" && choiceboxarray[i].getValue() != "Random"){
                ++counter;
            }
            if("Random" == choiceboxarray[i].getValue()){
                
                AnswerContainer ac1 = new AnswerContainer(0, 0 ,0,"pane" +counter, Questions.getrandom(), panes.get(counter-1));
                lists.add(counter-1,ac1);
                ++counter;
        }            
        } 

            if(counter >= 3){
        


                answerslist = lists;
                System.out.println("myello");
        Utility.changetoscene("FXMLDocument.fxml", event, getClass());
    }
        warning.setVisible(true);
    } }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    choicebox1.getItems().addAll(array);
    choicebox1.setValue("none");
    choicebox2.getItems().addAll(array);
    choicebox2.setValue("none");
    choicebox3.getItems().addAll(array);
    choicebox3.setValue("none");
    choicebox4.getItems().addAll(array);
    choicebox4.setValue("none");
    choicebox5.getItems().addAll(array);
    choicebox5.setValue("none");
        // TODO
    }    
    
}
