/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

/**
 *
 * @author duncan
 */
public class AnswerContainerManager {
    
    private static void checkquestion(AnswerContainer AC, Button activebutton){
                for(int i=0; i<AC.getAnswer().length; ++i){
                    
            if(AC.getAnswer()[i].equals(activebutton.getText())){
                int truehas = AC.getAnswershas();
                AC.setAnswershas(++truehas);
            }
        }
    }
    
    public static void checkhas(List<AnswerContainer> AC, Label[] correct){
        int check =0;
        for(int i=0; i<AC.size(); ++i){
                if(AC.get(i).getNeeds() == AC.get(i).getHas()){
            ++check;           
                }
        }
        if (check == AC.size()){
            for(int i=0; i<AC.size(); ++i){
                if(i == 3){
                correct[i +1].setVisible(true);
                correct[i +1].setText(AC.get(i).getAnswershas() + " are correct");                    
                }
                else if(i==4){
                correct[i-1].setVisible(true);
                correct[i-1].setText(AC.get(i).getAnswershas() + " are correct");                    
                }else{
                correct[i].setVisible(true);
                correct[i].setText(AC.get(i).getAnswershas() + " are correct");
                System.out.println(correct[i]);
            }}
        }
        else{
                      for(int i=0; i<AC.size(); ++i){
                correct[i].setVisible(false);
                correct[i].setText(AC.get(i).getAnswershas() + " are correct");
            }  
        }
    }
    
    public static Boolean checkwinning(List<AnswerContainer> AC){
        int check =0;
        for(int i=0; i<AC.size(); ++i){
                if(AC.get(i).getAnswershas() == AC.get(i).getNeeds()){
            ++check;           
                }
        }
        return check == AC.size();
    }
    
    public static void addquestion(GridPane grid, Button activebutton, List<AnswerContainer> AC, List<Button> buttonlist){
        System.out.println("hi");
        System.out.println(activebutton.getId());
        int index =0;
        while(!grid.getId().equals(AC.get(index).getGridid())){
            ++index;
        }
        System.out.println(AC.get(index).getGridid());
        checkquestion(AC.get(index), activebutton);
        System.out.println("yopes");
        activebutton.setId("activebutton");
        activebutton.setUnderline(false);

        System.out.println("is it?");
        for(int i=0; i<buttonlist.size(); ++i){
            if(buttonlist.get(i).getId().equals(activebutton.getId())){
                System.out.println(AC.get(index).getButtonList());
                    AC.get(index).getButtonList().add(buttonlist.get(i));
                break;
            }
        }
        System.out.println("slowly but surely");
        activebutton.setId(grid.getId());
        activebutton.setUnderline(true);
        int boxhas = AC.get(index).getHas() + 1;
        grid.add(activebutton, 0, boxhas);
        int has = AC.get(index).getHas();
        AC.get(index).setHas(++has);


        
        System.out.println(AC.get(index).getHas());
        System.out.println( AC.get(index).getNeeds());
        System.out.println(AC.get(index).getAnswershas());
    }
    
    public void containerfixer(List<AnswerContainer> AC, Button b, GridPane[] panes, GridPane answers){
        panes[0].setId("pane1");
        System.out.println(b.getId());
        int checker =0;
        for(int i=0; i<27; ++i){
            if(("id" +i).equals(b.getId()) ){
                checker=1;
                break;
            }
        }
        if(checker ==0){       
        int Cindex =0;
        String button = b.getId();
        List<String> ACL = new ArrayList<>();
        for(int i=0; i<AC.size(); ++i){
            ACL.add(AC.get(i).getGridid());
        }
        while(!ACL.get(Cindex).equals(button)){
            ++Cindex;
        }
        
        if(AC.get(Cindex).getButtonList().size()>0){
            String test = panes[0].getId();
        List<String> panesS = new ArrayList<>();
        for(int i=0; i<panes.length; ++i){
            panesS.add(panes[i].getId());
        }
        

        int index =0;
        while(!panesS.get(index).equals(button)){
            ++index;
        }
                    System.out.println("nopesss");
                    System.out.println(AC.get(index).getButtonList());
        for(int i =0; i<AC.get(Cindex).getButtonList().size(); ++i){
            answers.add(AC.get(index).getButtonList().get(i), 1, 1);
            panes[index].add(AC.get(index).getButtonList().get(i), 0, i +1);
        }
        } 
        }
    }
    
    public void resetname(Label[] labels, List<AnswerContainer> AC){ //me chucking stuff at a wall, seeing it worked, and being to scared to change it at all
         int count =0;
     int needs =0;
        if( count < HomescreenController.answerslist.size()){
            
            for(int i=0; i<AC.size(); ++i){
                System.out.println(i);
                if(AC.get(i).getAnswer()[0].equals(HomescreenController.answerslist.get(count).getAnswer()[0])){System.out.println(i);
                       labels[0].setText(HomescreenController.answerslist.get(i).getAnswer()[0] + ":" + '\n' +
       HomescreenController.answerslist.get(needs).getNeeds()+ " needed in total");  ++count; break;}    
                }

        ++needs;
        if( count < HomescreenController.answerslist.size()){            
            for(int i=0; i<AC.size(); ++i){
                if(AC.get(i).getAnswer()[0].equals(HomescreenController.answerslist.get(count).getAnswer()[0])){
       labels[1].setText(HomescreenController.answerslist.get(i).getAnswer()[0] + ":" + '\n' +
       HomescreenController.answerslist.get(needs).getNeeds()+ " needed in total");  ++count; break;                   
}    
                }
}
        ++needs;
        if( count < HomescreenController.answerslist.size()){            for(int i=0; i<AC.size(); ++i){
                if(AC.get(i).getAnswer()[0].equals(HomescreenController.answerslist.get(count).getAnswer()[0])){
       labels[2].setText(HomescreenController.answerslist.get(i).getAnswer()[0] + ":" + '\n' +
       HomescreenController.answerslist.get(needs).getNeeds()+ " needed in total");  ++count; break;                   
}    
                }
}
        ++needs;
        if( count < HomescreenController.answerslist.size()){            for(int i=0; i<AC.size(); ++i){
                if(AC.get(i).getAnswer()[0].equals(HomescreenController.answerslist.get(count).getAnswer()[0])){
       labels[3].setText(HomescreenController.answerslist.get(i).getAnswer()[0] + ":" + '\n' +
       HomescreenController.answerslist.get(3).getNeeds()+ " needed in total");  ++count; break;               
}    
                }
}
        ++needs;
        if( count < HomescreenController.answerslist.size()){            for(int i=0; i<AC.size(); ++i){
                if(AC.get(i).getAnswer()[0].equals(HomescreenController.answerslist.get(count).getAnswer()[0])){
       labels[4].setText(HomescreenController.answerslist.get(i).getAnswer()[0] + ":" + '\n' +
       HomescreenController.answerslist.get(4).getNeeds()+ " needed in total");  ++count;  break;                  
}    
                } 
}
        ++needs;
        System.out.println("peek");
}
}
}
